# Dkrajfashionstore — Deploy instructions

This project is a minimal ready-to-deploy Node + Express static site with Paytm checkout (staging).

1. Create a GitHub repo named `Dkrajfashionstore` and push all files.
2. In Render (or any host) set environment variables (do NOT commit real keys):
   - MERCHANT_ID
   - MERCHANT_KEY
   - PAYTM_WEBSITE (e.g. WEBSTAGING)
   - PAYTM_CHANNEL_ID (e.g. WEB)
   - PAYTM_INDUSTRY_TYPE_ID (e.g. Retail)
3. On Render: New -> Web Service -> Connect GitHub repo -> Branch main -> Start Command: `npm start` -> Create Web Service.
4. For Paytm production, update the Paytm URL in `public/product.html` to production endpoint `https://securegw.paytm.in/theia/processTransaction` and set `PAYTM_ENV=PRODUCTION`.

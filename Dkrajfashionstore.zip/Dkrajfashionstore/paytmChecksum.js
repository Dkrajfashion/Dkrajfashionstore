const crypto = require('crypto');

function generateChecksum(params, key) {
  const data = Object.keys(params).sort().map(k => `${k}:${params[k]}`).join('|');
  return crypto.createHmac('sha256', key).update(data).digest('hex');
}

module.exports = { generateChecksum };

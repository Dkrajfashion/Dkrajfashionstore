require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const { generateChecksum } = require('./paytmChecksum');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 3000;

// Serve homepage
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Serve product page
app.get('/product', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'product.html'));
});

// Create Paytm order (server-side)
app.post('/create-order', async (req, res) => {
  try {
    const { customerName, email, phone } = req.body;
    const orderId = 'ORDER_' + Date.now();
    const mid = process.env.MERCHANT_ID;
    const key = process.env.MERCHANT_KEY;
    const amount = String(499); // fixed product price for demo

    const paytmParams = {
      MID: mid,
      ORDER_ID: orderId,
      CUST_ID: email || 'CUST_' + Date.now(),
      TXN_AMOUNT: amount,
      CHANNEL_ID: process.env.PAYTM_CHANNEL_ID || 'WEB',
      WEBSITE: process.env.PAYTM_WEBSITE || 'WEBSTAGING',
      INDUSTRY_TYPE_ID: process.env.PAYTM_INDUSTRY_TYPE_ID || 'Retail',
      CALLBACK_URL: `${req.protocol}://${req.get('host')}/callback`
    };

    const checksum = generateChecksum(paytmParams, key || 'test_key');
    paytmParams.CHECKSUMHASH = checksum;

    // Return params to client
    res.json({ success: true, params: paytmParams });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Paytm callback endpoint (demo)
app.post('/callback', (req, res) => {
  // For demo, show success page
  res.sendFile(path.join(__dirname, 'public', 'success.html'));
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
